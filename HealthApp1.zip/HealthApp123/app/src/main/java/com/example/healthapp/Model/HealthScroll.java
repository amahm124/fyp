package com.example.healthapp.Model;

public class HealthScroll {
    private int image;
    public HealthScroll(int image){
        this.image=image;
    }

    public int getImage() {
        return image;
    }
}
